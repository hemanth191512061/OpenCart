$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/resources/feature/Opencart.feature");
formatter.feature({
  "line": 2,
  "name": "Opencart website",
  "description": "",
  "id": "opencart-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Testcase_Feature"
    }
  ]
});
formatter.scenario({
  "line": 99,
  "name": "",
  "description": "leave the username details in username",
  "id": "opencart-website;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 98,
      "name": "@tc12_opencart_leaveMandatoryDetails_login"
    }
  ]
});
formatter.step({
  "line": 102,
  "name": "let be the user launches the browser",
  "keyword": "Given "
});
formatter.step({
  "line": 103,
  "name": "let be the  user open opencart registration page",
  "keyword": "When "
});
formatter.step({
  "line": 104,
  "name": "let be the leave  the username in  register details",
  "keyword": "Then "
});
formatter.match({
  "location": "Leave_mandatoy_details_steps.the_user_launch_the_chrome_browser()"
});
formatter.result({
  "duration": 42378734651,
  "status": "passed"
});
formatter.match({
  "location": "Leave_mandatoy_details_steps.the_user_opens_opencart_register_page()"
});
formatter.result({
  "duration": 2983564156,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});