package com.Testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/main/resources/feature/Opencart.feature",
		plugin = {"pretty", "html:reports/cucumber-html-report"},
		tags = {"@tc08_opencart_invalidregistration_login"},
		glue = {"com.StepDefinition"},
		monochrome = true
		)


public class invalidregister_runner {

}
