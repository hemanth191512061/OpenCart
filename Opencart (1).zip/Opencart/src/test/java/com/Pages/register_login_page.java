package com.Pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.PendingException;
import junit.framework.Assert;

public class register_login_page 
{
	WebDriver driver;
	By my_account=By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a");
	By register=By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[1]/a");
	By first_name=By.name("firstname");
	By last_name=By.name("lastname");
	By email=By.name("email");
	By telephone=By.name("telephone");
	By password=By.name("password");
	By confirm=By.name("confirm");
	By agree=By.name("agree");
	By register_submit=By.xpath("//*[@id=\"content\"]/form/div/div/input[2]");
	By login=By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a");
	By login_submit=By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input");
	
	public void url(String browser) 
	{
		try
		{
			if(browser.equalsIgnoreCase("chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "src/test/resources/Driver/chromedriver.exe");
				driver=new ChromeDriver();
			}
			else if(browser.equalsIgnoreCase("firefox"))
			{
				System.setProperty("webdriver.gecko.driver","C:\\Users\\BLTuser.BLT1213\\Desktop\\selenium programs\\Selenium_hq\\Driver\\geckodriver.exe");
				driver=new FirefoxDriver();
			}
			
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			
		}
		
		catch(WebDriverException e)
		{
			System.out.println("Browser could not be launched");
		}
		
		driver.get("https://demo.opencart.com/");

	}
	
	public void opencart_register()
	{
		driver.findElement(my_account).click();
		driver.findElement(register).click();
	}
	
	public void register_details()
	{
		driver.findElement(first_name).sendKeys("yashwanth1");
		driver.findElement(last_name).sendKeys("yash");
		driver.findElement(email).sendKeys("kiranguntur1@gmail.com");
		driver.findElement(telephone).sendKeys("9123451431");
		driver.findElement(password).sendKeys("kiran5855");
		driver.findElement(confirm).sendKeys("kiran5855");
		driver.findElement(agree).click();
		driver.findElement(register_submit).click();
	}
	
	public void opencart_login()
	{
		driver.findElement(my_account).click();
		driver.findElement(login).click();
	}
	
	public void login_details(String emailid,String pass) throws InterruptedException
	{
		driver.findElement(email).sendKeys(emailid);
		driver.findElement(password).sendKeys(pass);
		driver.findElement(login_submit).click();
		
	}
	public void inlogin_details(String emailid,String pass) throws InterruptedException
	{
		driver.findElement(email).sendKeys(emailid);
		driver.findElement(password).sendKeys(pass);
		driver.findElement(login_submit).click();
		String match=driver.findElement(By.xpath("//*[@id=\"account-login\"]/div[1]")).getText();
		System.out.println(match);
		if(match.equalsIgnoreCase("Warning: Your account has exceeded allowed number of login attempts. Please try again in 1 hour."))
		{
			System.out.println("invalid details");
		}
		
	}
	public void invalidOnlyNum_login_details(String emailid,String pass) throws InterruptedException
	{
		driver.findElement(email).sendKeys(emailid);
		driver.findElement(password).sendKeys(pass);
		driver.findElement(login_submit).click();
		String match=driver.findElement(By.xpath("//*[@id=\"account-login\"]/div[1]")).getText();
		System.out.println(match);
		if(match.equalsIgnoreCase("Warning: Your account has exceeded allowed number of login attempts. Please try again in 1 hour."))
		{
			System.out.println("invalid details");
		}
		
	}
	public void invalidregister_details()
	{
		driver.findElement(first_name).sendKeys("yashwanth1");
		driver.findElement(last_name).sendKeys("yash");
		driver.findElement(email).sendKeys("kiranguntur@gmail.com");
		driver.findElement(telephone).sendKeys("9123451431");
		driver.findElement(password).sendKeys("kiran5855");
		driver.findElement(confirm).sendKeys("kiran5855");
		driver.findElement(agree).click();
		driver.findElement(register_submit).click();
		String match1=driver.findElement(By.xpath("//*[@id=\"account-register\"]/div[1]")).getText();
		System.out.println(match1);
		if(match1.equalsIgnoreCase("Warning: E-Mail Address is already registered!"))
		{
			System.out.println("user is already existed");
		}
	}
	public void leave_mandatory_details()
	{
		driver.findElement(first_name).sendKeys("yashwanth1");
		driver.findElement(last_name).sendKeys("yash");
		driver.findElement(email).sendKeys("kiranguntur1@gmail.com");
		driver.findElement(telephone).sendKeys("9123451431");
		driver.findElement(password).sendKeys("kiran5855");
		//driver.findElement(confirm).sendKeys("kiran5855");
		driver.findElement(agree).click();
		driver.findElement(register_submit).click();
		String mandatory=driver.findElement(By.xpath("//*[@id=\"account\"]/div[2]/div/div")).getText();
		if(mandatory.equalsIgnoreCase("First Name must be between 1 and 32 characters!")) {
			System.out.println("mandatory details need to be entered");
		}
		
	}
	
	
	
	public void close_login()
	{
		driver.close();
	}

}
