package com.Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class brand_page {
	WebDriver driver;
	By brand=By.xpath("/html/body/footer/div/div/div[3]/ul/li[1]/a");
	By manafacturer=By.xpath("//*[@id=\"content\"]/div[1]/div/a");
	public void launchappl(String browser)
	{try
	{
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "src/test/resources/Driver/chromedriver.exe");
			driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver","C:\\Users\\BLTuser.BLT1213\\Desktop\\selenium programs\\Selenium_hq\\Driver\\geckodriver.exe");
			driver=new FirefoxDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
	}
	
	catch(WebDriverException e)
	{
		System.out.println("Browser could not be launched");
	}
	}
	public void opencart_web()
	{
		driver.get("https://demo.opencart.com/");
		System.out.println(driver.getTitle());
	}
	public void choose_brands() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		driver.findElement(brand).click();
		driver.findElement(manafacturer).click(); 
		
	}
	public void close_the_browser()
	{
		//driver.close();
	}
}

