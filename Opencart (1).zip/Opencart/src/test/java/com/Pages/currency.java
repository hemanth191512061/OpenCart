package com.Pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class currency {
	WebDriver driver;
	By currdrop=By.xpath("//*[@id=\'form-currency\']/div/button/span");
	By nam=By.xpath("//*[@id=\"form-currency\"]/div/ul/li[2]/button");
	public void launbrow(String browser)
	{try
	{
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "src/test/resources/Driver/chromedriver.exe");
			driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver","C:\\Users\\BLTuser.BLT1213\\Desktop\\selenium programs\\Selenium_hq\\Driver\\geckodriver.exe");
			driver=new FirefoxDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
	}
	
	catch(WebDriverException e)
	{
		System.out.println("Browser could not be launched");
	}
	}
	public void opencart_pg()
	{
		driver.get("https://demo.opencart.com/");
		System.out.println(driver.getTitle());
	}
	public void choose_currency() throws InterruptedException
	{
		driver.findElement(currdrop).click();
	 driver.findElement(nam).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,1000)");
	
	}
	public void CheckPresenceOfCurrency() {
		//driver.findElement(currdrop).click();
		//Select Currency= new Select(driver.findElement(currdrop));
		List<WebElement> pageOption=  driver.findElements(currdrop);
		int size=pageOption.size();
		/*
		 * for(int i=0;i<size;i++) {
		 * System.out.println("============>"+pageOption.get(i).getText()+"<==========="
		 * ); }
		 */
		System.out.println(size);
		
	}
	public void close_site()
	{
		//driver.close();
	}
}
