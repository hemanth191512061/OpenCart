package com.StepDefinition;

import com.Pages.register_login_page;
import com.excel_util.excel_data;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class invallid_login_steps {

	register_login_page rl=new register_login_page();
	
	@Given("^the user have to launch the browser$")
	public void the_user_launch_the_chrome_browser() throws Throwable 
	{
		rl.url("chrome");
	 
	}

	@When("^the user open cart login page$")
	public void the_user_opens_opencart_login_page() throws Throwable 
	{
		rl.opencart_login();
	   
	}

	@Then("^the user enter the invalid login details$")
	public void the_user_enters_the_login_details() throws Throwable 
	{
		rl.inlogin_details("hema123@gmail.com","123");
		rl.close_login();
		
	    }
	
	    
	}



