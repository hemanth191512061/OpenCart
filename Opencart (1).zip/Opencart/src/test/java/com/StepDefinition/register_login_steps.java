package com.StepDefinition;

import com.Pages.register_login_page;
import com.excel_util.excel_data;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class register_login_steps 
{
	register_login_page rl=new register_login_page();
	excel_data excel=new excel_data();
	
	@Given("^the user launch the browser$")
	public void the_user_launch_the_chrome_browser() throws Throwable 
	{
		rl.url("chrome");
	 
	}

	@When("^the  user opens opencart register page$")
	public void the_user_opens_opencart_register_page() throws Throwable 
	{
		rl.opencart_register();
	    
	}

	@Then("^the user enters the register details$")
	public void the_user_enters_the_register_details() throws Throwable 
	{
		rl.register_details();
	   
	}

	@When("^the user opens opencart login page$")
	public void the_user_opens_opencart_login_page() throws Throwable 
	{
		rl.opencart_login();
	   
	}

	@Then("^the user enters the login details$")
	public void the_user_enters_the_login_details() throws Throwable 
	{
		rl.login_details(excel.excel_emailid(1),excel.excel_password(1));
		rl.close_login();
		
	    int count=excel.row_count();
	    for(int i=2;i<=count;i++)
	    {
	    rl.url("chrome");
	    rl.opencart_login();
	    rl.login_details(excel.excel_emailid(i),excel.excel_password(i));
	    rl.close_login();
	    }
	    
	}

}
