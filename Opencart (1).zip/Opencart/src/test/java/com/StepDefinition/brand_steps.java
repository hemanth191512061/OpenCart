package com.StepDefinition;

import com.Pages.brand_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class brand_steps {
	brand_page br=new brand_page();
	
@Given("^launching the browser$")
public void launching_the_browser() throws Throwable {
	   br.launchappl("chrome");
	}

@When("^the user opens the cart home page$")
public void the_user_opens_the_cart_home_page() throws Throwable {
   br.opencart_web();
}

@Then("^the user choose the company brand$")
public void the_user_choose_the_company_brand() throws Throwable {
br.choose_brands();
}

@Then("^the user close the cart site$")
public void the_user_close_the_cart_site() throws Throwable {
br.close_the_browser();
}

}
