package com.StepDefinition;

import com.Pages.currency;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class currency_steps {
	currency c=new currency();
	@Given("^launch browser$")
	public void launch_browser() throws Throwable {
	   c.launbrow("chrome");
	}

	@When("^the user open  home page$")
	public void the_user_open_home_page() throws Throwable {
	c.opencart_pg();
	}

	@Then("^the user select the currency$")
	public void the_user_select_the_currency() throws Throwable {
	    c.choose_currency();
	}

	@Then("^the user closes the browser$")
	public void the_user_closes_the_browser() throws Throwable {
c.close_site();
	}


}
