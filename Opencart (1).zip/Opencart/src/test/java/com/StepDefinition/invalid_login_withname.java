package com.StepDefinition;

import com.Pages.register_login_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class invalid_login_withname {
register_login_page rl=new register_login_page();
	
	@Given("^the user have to launches the browser$")
	public void the_user_launch_the_chrome_browser() throws Throwable 
	{
		rl.url("chrome");
	 
	}

	@When("^the user want to open cart login page$")
	public void the_user_opens_opencart_login_page() throws Throwable 
	{
		rl.opencart_login();
	   
	}

	@Then("^the user enter the invalid login details in username$")
	public void the_user_enters_the_login_details() throws Throwable 
	{
		rl.invalidOnlyNum_login_details("1234", "pass");
		rl.close_login();
		
	    }
	
	    

}
