package com.StepDefinition;

import com.Pages.register_login_page;
import com.excel_util.excel_data;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class invalid_registration_steps {
	register_login_page rl=new register_login_page();
	
	@Given("^the user launches the browser$")
	public void the_user_launch_the_chrome_browser() throws Throwable 
	{
		rl.url("chrome");
	 
	}

	@When("^the  user open opencart registration page$")
	public void the_user_opens_opencart_register_page() throws Throwable 
	{
		rl.opencart_register();
	    
	}

	@Then("^the user enters the same register details$")
	public void the_user_enters_the_register_details() throws Throwable 
	{
		rl.invalidregister_details();
	   
	}
	}

